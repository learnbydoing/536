case class SendInfo(title: String, url: String)
case object Flush
case object Done
case object START